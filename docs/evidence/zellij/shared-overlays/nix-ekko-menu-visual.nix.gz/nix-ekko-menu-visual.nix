{
  pkgs,
  ekko,
}:
pkgs.writeShellApplication {
  name = "finix-ekko-menu-visual";
  runtimeInputs = [pkgs.cage pkgs.kitty pkgs.grim (pkgs.python3.withPackages (p: [p.pillow]))];
  text = ''
    export LIBGL_DRIVERS_PATH="${pkgs.mesa}/lib/dri"
    export __EGL_VENDOR_LIBRARY_FILENAMES="${pkgs.mesa}/share/glvnd/egl_vendor.d/50_mesa.json"
    export FONTCONFIG_FILE="${pkgs.makeFontsConf {fontDirectories = [pkgs.dejavu_fonts];}}"
    exec python ${../tests/ekko-menu-visual.py} ${ekko}/bin/ekko ${../modules/shell/ekko/init.lisp} "''${1:-/tmp/finix-ekko-menu-visual}"
  '';
}
